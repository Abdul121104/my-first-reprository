#include <stdio.h>
int main(){
	int num,rev,d1,d2,d3,ori;
	printf("enter a 3 digit number");
	scanf("%d",&num);
	ori=num;
	d1=num%10;
	num=num/10;
	d2=num%10;
	num=num/10;
	d3=num%10;
	rev=d1*100+d2*10+d3;
	if(rev==ori)
	printf("num is palindrome");
	else
	printf("no is a palindrome");
	return 0;
	}
	
	
	
	
