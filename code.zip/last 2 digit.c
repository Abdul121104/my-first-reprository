#include <stdio.h>
int main(){
	int a,b,d1,d2;
	printf("enter a no");
	scanf("%d",&a);
	b=a;
	d1=a%10;
	a=a/10;
	d2=a%10;
	printf("the last two digit are");
	printf("\n%d",d2);
	printf("\n%d",d1);
	return 0;
}
