#include<stdio.h>
#include<math.h>
int main()
{
	float a,b,c;
	printf("enter adjacent lenght");
	scanf("%f,%f",&a,&b);
	c=sqrt(pow(a,2)+pow(b,2));
	printf("lenght of hypoteneus=%f",c);
	return 0;
}
