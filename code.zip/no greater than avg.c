#include <stdio.h>
int main()
{
	int avg,a1,a2,a3,a4,a5,a6,a7;
	printf("enter 7 no");
	scanf("%d%d%d%d%d%d%d",&a1,&a2,&a3,&a4,&a5,&a6,&a7);
	avg=(a1+a2+a3+a4+a5+a6+a7)/7;
	if(a1>avg)printf("\n%d",a1);
	if(a2>avg)printf("\n%d",a2);
	if(a3>avg)printf("\n%d",a3);
	if(a4>avg)printf("\n%d",a4);
	if(a5>avg)printf("\n%d",a5);
	if(a6>avg)printf("\n%d",a6);
	if(a7>avg)printf("\n%d",a7);
	return 0;
}
