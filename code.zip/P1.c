#include<stdio.h>
int main ()
{
	int a,b,c,d,e;
	printf("enter 5 marks");
	scanf("%d%d%d%d%d",&a,&b,&c,&d,&e);
	float avg;
	avg=(a+b+c+d+e)/5.0;
	printf("average is :%f",avg);
	return 0;
}







