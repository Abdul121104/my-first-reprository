#include<stdio.h>
int main()
{
	int a,b,sum;
	printf("Enter two number");
	scanf("%d %d",&a,&b);
	sum=a+b;
	printf("sum of two number=%d",sum);
	return 0;
}
	
   
