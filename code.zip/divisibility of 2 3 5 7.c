#include <stdio.h>
int main(){
	int a;
	printf("enter a no");
	scanf("%d",&a);
	if(a%2==0){
		printf("\n%d is div by 2",a);
	}
	if(a%7==0){
		printf("\n%d is div by 7",a);
	}
	if(a%3==0){
		printf("\n%d is div by 3",a);
	}
	if(a%5==0){
		printf("\n%d is div by 5",a);
	}
	return 0;
}
