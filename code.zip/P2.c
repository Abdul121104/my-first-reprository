#include<stdio.h>
int main()
{
	int a,b;
	printf("enter radius");
	scanf("%d,%d",&a,&b);
	a=3.14*a*a;
	b=3.14*a;
	printf("\narea of circle=%d",a);
	printf("\nperimeter of circle=%d",b);
	return 0;
}


