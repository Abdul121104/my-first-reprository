#include<stdio.h>
int main(){
	int fac,a,b,i;
	printf("enter a number");
	scanf("%d",&a);
	i=0;
	fac=1;
	b=a-i;
	while(i<5){
		b=a-i;
		fac=fac*b;
		i=i+1;
	}
	printf("factorial of no is %d",fac);
	return 0;
}        
