#include<stdio.h>
int main(){
	int sum,a,b;
	printf("enter a number");
	scanf("%d",&a);
	sum=0;
	while(a>0){
		b=a%10;
		sum=sum+b;
		a=a/10;
	}
	printf("sum of digit is %d",sum);
	return 0;
} 
