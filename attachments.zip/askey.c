#include<stdio.h>
int main(){
	char a,b;
	printf("enter one alphabets");
	scanf("%c %c",&a,&b);
	int c=a;
	int d=b;
	printf("\n%d\n%d",c,d);
	return 0;
}
