//simple calculator using switch
//the sum of digits of positive integer number
#include<stdio.h>
int main(){
    char i=1;
	while(i=1){
		char ch;
	float a,b;
	printf("enter which operation u want\n+\n-\n*\n/");
	scanf("%c",&ch);
	printf("enter two no");
	scanf("%f%f",&a,&b);
	switch(ch){
		case '+':
			printf("%f",a+b);
			break;
		case '-':
			printf("%f",a-b);
			break;
		case '*':
			printf("%f",a*b);
			break;
		case '/':
			printf("%f",a/b);
			break;
		}
	}
		return 0;
 
}

